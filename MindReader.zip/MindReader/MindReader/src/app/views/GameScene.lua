
local TAG_PATTERN_BEGIN = 99
local TAG_PATTERN_COUNT = 100

local GameScene = class("GameScene", cc.load("mvc").ViewBase)

-- ����csb�ļ�
GameScene.RESOURCE_FILENAME = "GameScene.csb"

--��ȡUI�ؼ�
GameScene.RESOURCE_BINDING = {
    ["ball"]   = {["varname"] = "ball"},
    ["pattern"]   = {["varname"] = "pattern"},
    ["again"] = {["varname"] = "again"},
    ["star"] = {["varname"] = "star"},
}

function GameScene:onCreate()
    self:addPatterns()
    self:startBlink()
    self.again:addClickEventListener(handler(self, self.onButtonClick))
    self.ball:addClickEventListener(handler(self, self.onButtonClick))
    --printf("resource node = %s", tostring(self:getResourceNode()))
end

function GameScene:addPatterns()
    local col = 0
    local row = 0
    for col = 0,4 do
        local x = 427.2 - 44 * col
        for row = 0,19 do
            local y = 33 + 13.45 * row
            local name = self:getPatternName()
            local sp = cc.Sprite:createWithSpriteFrameName(name)
            local idx = col * 20 + row
            sp:setTag(TAG_PATTERN_BEGIN + idx)
            sp:setPosition(x,y)
            sp:setScale(0.39)
            sp:setColor(cc.c3b(255, 255, 0))
            self:addChild(sp)
        end    
    end
    
    self:resetPattern()
end

function GameScene:startBlink()
    local scheduler = self:getScheduler()
    scheduler:scheduleScriptFunc(handler(self, self.blink), 0.5, false)
end

function GameScene:blink(dt)
    local x = self.ball:getPositionX()
    local y = self.ball:getPositionY()
    local r = self.ball:getBoundingBox().width / 2
    local theta = math.random(0, 2 * math.pi)
    r = math.random(0,r)
    x = x + math.cos(theta) * r
    y = y + math.sin(theta) * r
    self.star:setPosition(x,y)
    self.star:setScale(math.random(0.72, 0.81))
end

function GameScene:onButtonClick(sender,x,y,z)
    local name = sender:getName()
    if (name=="ball") then
        local sp = self:getChildByTag(TAG_PATTERN_BEGIN)
        local frame = sp:getSpriteFrame()
        self.pattern:setSpriteFrame(frame)
        self.pattern:setVisible(true)
        self.again:setVisible(true)
    else
        self.pattern:setVisible(false)
        self.again:setVisible(false)
        self:resetPattern()
    end
end

function GameScene:getPatternName()
    return string.format("%d.png", math.random(0,71))
end

function GameScene:resetPattern()
    local spriteFrameCache = cc.SpriteFrameCache:getInstance()
    local name = self:getPatternName()
    local idx = 0
    for idx = 0, TAG_PATTERN_COUNT-1 do
        local tag = TAG_PATTERN_BEGIN + idx
        local sp = self:getChildByTag(tag)
        local _name = 0 ~= math.mod(idx,9) and self:getPatternName() or name
        local frame = spriteFrameCache:getSpriteFrame(_name)
        --sp:setName(_name)
        sp:setSpriteFrame(frame)
    end
end

return GameScene