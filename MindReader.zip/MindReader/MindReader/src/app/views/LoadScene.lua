
local LoadScene = class("LoadScene", cc.load("mvc").ViewBase)

--LoadScene.RESOURCE_FILENAME = "MainScene.csb"
function LoadScene:onCreate()
    self:addLogo()
    self:addLabel()
    self:startSchedule()
end

function LoadScene:addLogo()
    local sp = cc.Sprite:create("logo.png")
    sp:setPosition(display.cx, display.cy + 27)
    self:addChild(sp, 0, 0)
end

function LoadScene:addLabel()
    local sp = self:getChildByTag(0)
    local rect = sp:getBoundingBox()
    local fontsize = 18;
    local label = cc.LabelTTF:create("Loading...", "", fontsize)
    local x = cc.rectGetMidX(rect)
    local y = cc.rectGetMinY(rect) - fontsize * 0.8
    label:setPosition(x, y)
    self:addChild(label)

    label:runAction(self:createAction())
end

function LoadScene:createAction()
    local seq = cc.Sequence:create(cc.ScaleTo:create(0.5, 1.05), cc.ScaleTo:create(0.5, 1.0))
    return cc.RepeatForever:create(seq)
end

function LoadScene:startSchedule()
    local delay = cc.DelayTime:create(1.5)
    local callfunc = cc.CallFunc:create(self.startGame)
    local seq = cc.Sequence:create(delay, callfunc)
    self:runAction(seq)
end

function LoadScene:startGame()
     self:getApp():enterScene("GameScene")
end

return LoadScene