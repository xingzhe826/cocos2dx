
local MyApp = class("MyApp", cc.load("mvc").AppBase)

function MyApp:onCreate()
    self.configs_.defaultSceneName = "LoadScene"
    math.randomseed(os.time())
end

return MyApp
