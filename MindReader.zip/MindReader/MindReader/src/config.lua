
-- 0 - disable debug info, 1 - less debug info, 2 - verbose debug info
DEBUG = 2

-- use framework, will disable all deprecated API, false - use legacy API
CC_USE_FRAMEWORK = true

-- show FPS on screen
CC_SHOW_FPS = false

-- disable create unexpected global variable
CC_DISABLE_GLOBAL = true

-- for module display
CC_DESIGN_RESOLUTION = {
    width = 480,
    height = 320,
    autoscale = "EXACT_FIT",
    callback = function(framesize)
        if "windows" == device.platform then
            local director = cc.Director:getInstance()
            local view = director:getOpenGLView()
            framesize.width = 480
            framesize.height = 320
            view:setFrameSize(framesize.width,framesize.height) 
        end

        local ratio = framesize.width / framesize.height
        if ratio <= 1.34 then
            -- iPad 768*1024(1536*2048) is 4:3 screen
            return {autoscale = "EXACT_FIT"}
        end
    end
}
