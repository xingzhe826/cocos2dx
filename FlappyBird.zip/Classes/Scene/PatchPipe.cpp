#include "PatchPipe.h"
#include "Global/GUtils.h"

using namespace cocos2d;

PatchPipe* PatchPipe::create(const Size& size, float xSpace)
{
	auto patch = new(std::nothrow) PatchPipe();
	if (NULL != patch)
	{
		if (patch->init(size, xSpace))
			patch->autorelease();
		else
			CC_SAFE_DELETE(patch);
	}
	return patch;
}

bool PatchPipe::init(const Size& size, float xSpace)
{
	if (!Node::init())  return false;

	setAnchorPoint(Vec2::ANCHOR_MIDDLE);
	setContentSize(size);
	m_xSpace = xSpace;
	m_yShake = 0;
	m_iL = -1;

	return true;
}

void PatchPipe::onEnter()
{
	Node::onEnter();

	if (m_iL < 0)  reset();
}

void PatchPipe::reset()
{
	// ������س�Ա����
	m_nChildren = getChildrenCount();
	CC_ASSERT(m_nChildren > 1);
	m_iL = 0;

	// �����ӽڵ�λ��
	auto size = getBoundingBox().size;
	auto pt = m_ptInit;
	for (auto& child : _children)
	{
#if defined(COCOS2D_DEBUG) && COCOS2D_DEBUG > 0 
		auto sz = child->getBoundingBox().size;
		CC_ASSERT(!sz.equals(Size::ZERO) && compare(sz.width / 2, m_xSpace) < 0);
#endif
		pt.y += m_yShake * random(-0.5f, 0.5f);
		child->setPosition(pt);
		pt.x += m_xSpace;

		if (NULL != m_callback)  m_callback(child);
	}
}

void PatchPipe::setPipeCallback(const PipeCallback& callback)
{
	m_callback =  callback;
}

void PatchPipe::setInitPosition(const cocos2d::Point& pt)
{
	m_ptInit = pt;
}

void PatchPipe::setShakeY(float y)
{
	m_yShake = y;
}

void PatchPipe::startMoving(float dt, float xStep)
{
	schedule(CC_CALLBACK_1(PatchPipe::moving, this, xStep), dt, "moving");
}

void PatchPipe::stopMoving()
{
	unschedule("moving");
}

void PatchPipe::moving(float dt, float xStep)
{
	auto size = getBoundingBox().size;
	auto node = _children.at(m_iL);
	auto box = node->getBoundingBox();
	auto dx = m_nChildren * m_xSpace;
	if (compare(box.getMinX() + dx - xStep, size.width) <= 0)
	{// �����ƶ�����˽��
		CC_ASSERT(compare(box.getMaxX(), 0) < 0);

		auto pt = node->getPosition();
		pt.x += dx;
		pt.y = m_ptInit.y + m_yShake * random(-0.5f, 0.5f);
		node->setPosition(pt);
		m_iL = (m_iL + 1) % m_nChildren;

		if (NULL != m_callback)  m_callback(node);
	}

	// �����ƶ�
	for (auto& child : _children)
		child->setPositionX(child->getPositionX() - xStep);
}
