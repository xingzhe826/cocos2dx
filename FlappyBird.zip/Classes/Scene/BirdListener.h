#ifndef __BIRD_LISTENER_H__
#define __BIRD_LISTENER_H__

// ����С���߼�����
#include "cocos2d.h"
class BirdSprite;

class BirdListener : public cocos2d::EventListenerTouchOneByOne
{
public:
	static BirdListener* create(BirdSprite* bird);

public:
	/*virtual*/ bool init(BirdSprite* bird);

	// �����¼�
	/*virtual*/ bool onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* unused_event);
	/*virtual*/ void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* unused_event);
	/*virtual*/ void onTouchCancelled(cocos2d::Touch* touch, cocos2d::Event* unused_event);
	
public:
	BirdSprite* getBird() const;
	void setEnabled(bool enabled);

private:
	BirdSprite*			m_bird;
};


#endif // !__BIRD_LISTENER_H__