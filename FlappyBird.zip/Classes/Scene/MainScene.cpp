#include "MainScene.h"
#include "cocos2d.h"
#include "cocos-ext.h"
#include "OverDialog.h"

using namespace cocos2d;
using namespace cocos2d::extension;

Scene* MainScene::createScene()
{
	auto scene = Scene::create();
	auto lyr = MainScene::create();
	scene->addChild(lyr);

	return scene;
}

bool MainScene::init()
{
	if (!Layer::init())  return false;

	addBackground();
	addLogo();
	addBird();
	addPlayButton();
	addLand();

	return true;
}

void MainScene::addPlayButton()
{
	auto btn = OverDialog::createPlayButton();
	auto size = Director::getInstance()->getVisibleSize();
	btn->addTargetWithActionForControlEvents(this,
		cccontrol_selector(BaseLayer::onButton), Control::EventType::TOUCH_UP_INSIDE);
	btn->setPosition(size.width / 2, size.height / 2 - 140);

	addChild(btn);
}

