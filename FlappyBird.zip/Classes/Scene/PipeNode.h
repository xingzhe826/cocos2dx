#ifndef __PIPE_NODE_H__
#define __PIPE_NODE_H__

#include "cocos2d.h"

class ColorSprite;

class PipeNode :  public cocos2d::Node
{
public:
	CREATE_FUNC(PipeNode);

private:
	virtual bool init();

public:
	void goThrough();
	void randColor() const;

private:
	ColorSprite* createPipe(bool bTop) const;
	float getSpaceH() const;

private:
	ColorSprite*	m_top;
	ColorSprite*	m_bot;
};

#endif