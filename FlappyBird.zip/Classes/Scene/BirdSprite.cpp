#include "BirdSprite.h"
#include "cocos2d.h"
#include "Global/GManager.h"

using namespace cocos2d;

int8 BirdSprite::m_dH = -1;
int8 BirdSprite::m_dS = -1;

void BirdSprite::resetColor()
{
	m_dH = random(0, 101);
	m_dS = random(0, 101);
}

bool BirdSprite::init()
{
	std::string frmName = getBirdFrameName(0);
	if (!ColorSprite::initWithSpriteFrameName(frmName))  return false;

	if (m_dH < 0)  resetColor();

	m_gravity = GRAVITY_VALUE;
	setDieState(false);

	// ɫ��
	setName("bird");
	setDeltaH(getDH());
	setDeltaS(getDS());

	// ����
	m_wingAction = createWing();
	m_idleAction = createIdle();
	wing();
	idle();

	return true;
}

void BirdSprite::wing()
{
	runAction(m_wingAction);
}

void BirdSprite::idle()
{
	runAction(m_idleAction);
}

void BirdSprite::stopIdle()
{
	stopAction(m_idleAction);
}

void BirdSprite::fly()
{
	stopAction(m_idleAction);
	runAction(m_wingAction);
}

void BirdSprite::die(float rot, const cocos2d::Point& pt)
{
	setDieState(true);

	auto mgr = GManager::getInstance();
	mgr->stopAllEffect();
	mgr->playSound(SNDID_HIT);

	auto rb = RotateBy::create(0.27f, rot);
	auto mt = MoveTo::create(0.72f, pt);
	auto spw = Spawn::createWithTwoActions(rb, mt);
	auto seq = Sequence::createWithTwoActions(spw, CallFunc::create([=]{
		mgr->playSound(SNDID_HIT);
	}));
	stopAction(m_wingAction);
	runAction(seq);
}

void BirdSprite::flyUp()
{
	m_body->setVelocity(Vect(0, m_gravity));
}

void BirdSprite::fall()
{
	m_body->setVelocity(Vect(0, -m_gravity));
}

void BirdSprite::setPhysicsBody()
{
	auto size = getBoundingBox().size;
	m_body = PhysicsBody::createCircle(size.width / 2);
	m_body->setGravityEnable(false);
	m_body->setCategoryBitmask(MASK_CATEGORY_BIRD);
	m_body->setCollisionBitmask(MASK_COLLISION_BIRD);
	m_body->setContactTestBitmask(MASK_CONTACTTEST_BIRD);

	ColorSprite::setPhysicsBody(m_body);
}

cocos2d::ActionInterval* BirdSprite::createWing() const
{
	auto animation = Animation::create();
	animation->setDelayPerUnit(0.2f);
	for (int i = 0; i < 3; ++i)
	{
		std::string frmName = getBirdFrameName(i);
		auto frame = SpriteFrameCache::getInstance()->getSpriteFrameByName(frmName);
		animation->addSpriteFrame(frame);
	}
	auto ani = Animate::create(animation);
	auto wing = RepeatForever::create(ani);
	wing->setTag(TAG_ACTION_BIRD_WING);

	return wing;
}

cocos2d::ActionInterval* BirdSprite::createIdle() const
{
	auto mb0 = MoveBy::create(2.0f, Vec2(0, 49));
	auto mb1 = MoveBy::create(1.8f, Vec2(0, -49));
	auto seq = Sequence::createWithTwoActions(mb0, mb1);
	auto idle = RepeatForever::create(seq);
	idle->setTag(TAG_ACTION_BIRD_IDLE);

	return idle;
}

std::string BirdSprite::getBirdFrameName(int idx) const
{
	char szBird[16];
	sprintf(szBird, "bird%d.png", idx);
	return szBird;
}

float BirdSprite::getDH() const
{
	return m_dH / 100.0f * 360;
}

float BirdSprite::getDS() const
{
	return -0.3f + m_dS / 100.0f * 1.3f;
}
