#include "PipeNode.h"
#include "Global/GConfig.h"
#include "Objects/ColorSprite.h"

using namespace cocos2d;

bool PipeNode::init()
{
	
	if (!Node::init())  return false;

	// �����Ϲܵ�����ʼ����ر���
	m_top = createPipe(true);
	auto size = m_top->getContentSize();
	size.height = getSpaceH();

	// �����Ϲܵ�
	m_top->setPosition(size.width / 2, size.height);
	addChild(m_top);

	// ��������ܵ�
	m_bot = createPipe(false);
	m_bot->setPosition(size.width / 2, 0);
	addChild(m_bot);

	// �������
	auto body = PhysicsBody::createEdgeSegment(Vec2(size.width / 2, -size.height / 2), Vec2(size.width / 2, size.height / 2));
	body->setDynamic(false);
	body->setCategoryBitmask(MASK_CATEGORY_PIPENODE);
	body->setCollisionBitmask(MASK_COLLISION_PIPENODE);
	body->setContactTestBitmask(MASK_CONTACTTEST_PIPENODE);
	setName("PipeNode");
	setTag(TAG_SCENE_PIPENODE);
	setPhysicsBody(body);
	setAnchorPoint(Vec2::ANCHOR_MIDDLE);
	setContentSize(size);

	return true;
}

void PipeNode::goThrough()
{
	m_bot->getPhysicsBody()->setCollisionBitmask(MASK_COLLISION_PIPENODE);
}

void PipeNode::randColor() const
{
	m_top->setDeltaH(random(0, 360));
	m_top->setDeltaS(random(-1.0f, 1.0f));
	m_bot->setDeltaH(random(0, 360));
	m_bot->setDeltaS(random(-1.0f, 1.0f));
}

ColorSprite* PipeNode::createPipe(bool bTop) const
{
	float dy = getSpaceH() / 2;
	auto sp = ColorSprite::createWithSpriteFrameName("pipe.png");
	auto body = PhysicsBody::createBox(sp->getContentSize());
	body->setCategoryBitmask(MASK_CATEGORY_PIPE);
	body->setCollisionBitmask(MASK_COLLISION_PIPE);
	body->setContactTestBitmask(MASK_CONTACTTEST_PIPE);
	body->setDynamic(false);
	sp->setPhysicsBody(body);
	sp->setName("pipe");
	if (!bTop)
	{
		sp->setTag(TAG_SCENE_PIPEBOT);
		sp->setFlippedY(true);
		sp->setAnchorPoint(Vec2::ANCHOR_MIDDLE_TOP);
	}
	else
	{
		sp->setTag(TAG_SCENE_PIPETOP);
		sp->setAnchorPoint(Vec2::ANCHOR_MIDDLE_BOTTOM);
	}

	return sp;
}

float PipeNode::getSpaceH() const
{
	auto size = Director::getInstance()->getVisibleSize();
	return FY_DIST_PIPE * size.height;
}
