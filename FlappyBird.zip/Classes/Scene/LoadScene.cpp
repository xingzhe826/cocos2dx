#include "LoadScene.h"
#include "../Global/GManager.h"

using namespace cocos2d;

Scene* LoadScene::createScene()
{
    auto scene = Scene::create();
    auto layer = LoadScene::create();
    scene->addChild(layer);
    return scene;
}

bool LoadScene::init()
{
	if (!Layer::init())  return false;

	// ����logo
	auto size = Director::getInstance()->getVisibleSize();
	auto sp = Sprite::create("logo.png");
	sp->setPosition(size.width/2, size.height/2);
	addChild(sp);

	// ���Ӽ���
	auto fontSize = 18;
	auto label = Label::createWithSystemFont("Loading...", "", fontSize);
	auto action0 = ScaleTo::create(1.0f, 1.05f);
	auto action1 = ScaleTo::create(1.0f, 1.0f);
	auto seq = Sequence::createWithTwoActions(action0, action1);
	label->runAction(RepeatForever::create(seq));
	label->setPosition(size.width / 2, (size.height - sp->getContentSize().height) / 2 - fontSize*0.8f);
	addChild(label);


	// �첽����
	m_bFinished = false;
	Director::getInstance()->getTextureCache()->addImageAsync(PLIST_IMAGES_PNG, CC_CALLBACK_1(LoadScene::loadCallbackAysn, this));

    return true;
}

void LoadScene::loadCallbackAysn(cocos2d::Texture2D* texture)
{
	GManager::getInstance()->init();
	GManager::getInstance()->gotoScene(SID_MAINSCENE);
}