#ifndef __BIRD_SPRITE_H__
#define __BIRD_SPRITE_H__

#include "Global/GTypes.h"
#include "Objects/ColorSprite.h"
#include "cocos2d.h"

class BirdSprite : public ColorSprite
{
public:
	CREATE_FUNC(BirdSprite)
	CC_SYNTHESIZE(bool, m_bDie, DieState)

public:
	static void resetColor();

public:
	virtual bool init();

public:
	void wing();
	void idle();
	void stopIdle();
	void fly();
	void die(float rot, const cocos2d::Point& pt);
	void flyUp();
	void fall();
	void setPhysicsBody();
	
private:
	cocos2d::ActionInterval* createWing() const;
	cocos2d::ActionInterval* createIdle() const;
	std::string getBirdFrameName(int idx) const;
	float getDH() const;	// [0, 360]
	float getDS() const;	// [-1, 1]--->[-0.3, 1]
	
private:
	cocos2d::ActionInterval*	m_wingAction;
	cocos2d::ActionInterval*	m_idleAction;
	cocos2d::PhysicsBody*		m_body;
	static int8					m_dH;
	static int8					m_dS;
	float						m_gravity;
};

#endif