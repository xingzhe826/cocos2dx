#include "BirdListener.h"
#include "Global/GConfig.h"
#include "BirdSprite.h"

using namespace cocos2d;

BirdListener* BirdListener::create(BirdSprite* pTarget)
{
	auto listener = new(std::nothrow) BirdListener();
	if (NULL != listener)
	{
		if (listener->init(pTarget))
			listener->autorelease();
		else
			CC_SAFE_DELETE(listener);
	}

	return listener;
}

bool BirdListener::init(BirdSprite* bird)
{
	if (!EventListenerTouchOneByOne::init())  return false;
	
	m_bird = bird;

	EventListenerTouchOneByOne::onTouchBegan = CC_CALLBACK_2(BirdListener::onTouchBegan, this);
	EventListenerTouchOneByOne::onTouchEnded = CC_CALLBACK_2(BirdListener::onTouchEnded, this);
	EventListenerTouchOneByOne::onTouchCancelled = CC_CALLBACK_2(BirdListener::onTouchCancelled, this);

	return true;
}

bool BirdListener::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* unused_event)
{
	// С�����Ϸ�
	m_bird->flyUp();
	return true;
}

void BirdListener::onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* unused_event)
{
	m_bird->fall();
}

void BirdListener::onTouchCancelled(cocos2d::Touch* touch, cocos2d::Event* unused_event)
{
	m_bird->fall();
}

BirdSprite* BirdListener::getBird() const
{
	return m_bird;
}

void BirdListener::setEnabled(bool enabled)
{
	EventListenerTouchOneByOne::setEnabled(enabled);
	if (enabled)
	{
		m_bird->stopIdle();
		m_bird->fall();
	}
}