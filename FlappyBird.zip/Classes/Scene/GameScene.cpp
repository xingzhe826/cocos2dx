#include "GameScene.h"
#include "Global/GManager.h"
#include "PipeNode.h"
#include "BirdListener.h"
#include "PatchPipe.h"
#include "BirdSprite.h"
#include "OverDialog.h"

using namespace cocos2d;
using namespace cocos2d::extension;

GameScene::GameScene(cocos2d::PhysicsWorld* world) : m_world(world)
{
#if defined(COCOS2D_DEBUG) && COCOS2D_DEBUG > 0
//	world->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
#endif
	world->setGravity(Vect(0, -GRAVITY_VALUE));
}

GameScene::~GameScene()
{
}

GameScene* GameScene::create(cocos2d::PhysicsWorld* world)
{
	auto scene = new(std::nothrow) GameScene(world);
	if (NULL != scene)
	{
		if (scene->init())
			scene->autorelease();
		else
			CC_SAFE_DELETE(scene);
	}

	return scene;
}

Scene* GameScene::createScene()
{
	auto scene = Scene::createWithPhysics();
	auto world = scene->getPhysicsWorld();
	auto lyr = GameScene::create(world);
	scene->addChild(lyr);

	return scene;
}

bool GameScene::init()
{
	if (!Layer::init())  return false;

	addBackground();
	addLogo();
	addPatchPipe();
	addLevel();
	addLand();
	addBird();
	addTutorial();
	addContactListener();

	return true;
}

void GameScene::onButton(cocos2d::Ref* pSender, cocos2d::extension::Control::EventType type)
{
	auto btn = dynamic_cast<ControlButton*>(pSender);
	if (NULL != btn)
	{
		btn->setEnabled(false);
		startPlay();
	}
}

cocos2d::Point GameScene::getDiePosition() const
{
	auto bird = m_birdListener->getBird();
	auto size = bird->getBoundingBox().size;
	float x = m_birdListener->getBird()->getPositionX();
	float y = m_land->getBoundingBox().getMaxY() /*+ size.height / 4*/;

	return cocos2d::Point(x, y);
}

void GameScene::addBackground()
{
	BaseLayer::addBackground();

	// Celing��������body
	auto size = Director::getInstance()->getVisibleSize();
	auto body = PhysicsBody::createEdgeSegment(Vec2(-size.width / 2, size.height / 2), Vec2(size.width / 2, size.height / 2));
	body->setDynamic(false);
	body->setCategoryBitmask(MASK_CATEGORY_CEILING);
	body->setCollisionBitmask(MASK_COLLISION_CEILING);
	body->setContactTestBitmask(MASK_CONTACTTEST_CEILING);
	setName("ceiling");
	setPhysicsBody(body);
}

void GameScene::addLogo()
{
	BaseLayer::addLogo();

	auto size = Director::getInstance()->getVisibleSize();
	auto logo = (Label*)getChildByTag(TAG_SCENE_LOGO);
	logo->setString("Get Ready!");
	logo->setTextColor(Color4B::GREEN);
	logo->enableShadow(Color4B::WHITE, Size(1, -2));
	logo->setPosition(size.width / 2, size.height / 2 + 100);
}

void GameScene::addBird()
{
	BaseLayer::addBird();
	
	auto bird = (BirdSprite*)getChildByTag(TAG_SCENE_BIRD);
	bird->setPhysicsBody();

	m_birdListener = BirdListener::create(bird);
	m_birdListener->setEnabled(false);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(m_birdListener, this);
}

void GameScene::addLand()
{
	BaseLayer::addLand();
	// Land��������body
	m_land = getChildByTag(TAG_SCENE_LAND);
	auto size = m_land->getBoundingBox().size;
	auto body = PhysicsBody::createEdgeSegment(Vec2(-size.width / 2, size.height / 2), Vec2(size.width / 2, size.height / 2));
	body->setDynamic(false);
	body->setCategoryBitmask(MASK_CATEGORY_LAND);
	body->setCollisionBitmask(MASK_COLLISION_LAND);
	body->setContactTestBitmask(MASK_CONTACTTEST_LAND);
	m_land->setPhysicsBody(body);
}

void GameScene::addPatchPipe()
{
	auto size = Director::getInstance()->getVisibleSize();
	float xSpace = FX_DIST_PIPE * size.width;
	m_patch = PatchPipe::create(size, xSpace);
	m_patch->setInitPosition(Point(1.2f * size.width, size.height/2));
	m_patch->setShakeY(FY_SHAKE_PIPE * size.height);
	m_patch->addChild(PipeNode::create());
	m_patch->addChild(PipeNode::create());
	m_patch->setPosition(size.width / 2, size.height / 2);
	m_patch->setPipeCallback([](cocos2d::Ref* pSender){((PipeNode*)pSender)->randColor();});
	addChild(m_patch);
}

void GameScene::addLevel()
{
	auto size = Director::getInstance()->getVisibleSize();
	m_level = Label::createWithTTF("0", TTF_FLAPPYBIRD, 49);
	m_level->setTag(TAG_SCENE_LEVEL);
	m_level->setUserData((void*)0);
	m_level->enableShadow(Color4B::BLACK, Size(2, -3));
	m_level->setPosition(size.width / 2, size.height / 2 + 180);
	addChild(m_level);
}

void GameScene::addTutorial()
{
	auto btn = OverDialog::createButton("tutorial.png");
	auto size = Director::getInstance()->getVisibleSize();
	btn->setZoomOnTouchDown(false);
	btn->setTag(TAG_SCENE_TUTORIAL);
	btn->addTargetWithActionForControlEvents(this,
		cccontrol_selector(BaseLayer::onButton), Control::EventType::TOUCH_UP_INSIDE);
	btn->setPosition(size.width / 2, size.height / 2 - 140);
	
	addChild(btn);
}

void GameScene::addContactListener()
{
	auto listener = EventListenerPhysicsContact::create();
	listener->onContactBegin = CC_CALLBACK_1(GameScene::onContactBegin, this);
	listener->onContactSeparate = CC_CALLBACK_1(GameScene::onContactSeparate, this);
	
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
}

void GameScene::startPlay()
{
	GManager::getInstance()->playSound(SNDID_WING, true);
	GManager::getInstance()->playSound(SNDID_SWOOSH);

	m_birdListener->setEnabled(true);
	m_patch->startMoving(0.1f, X_OFFSET_PIPE);

	auto node = getChildByTag(TAG_SCENE_LOGO);
	node->runAction(FadeOut::create(1.0f));
	node = getChildByTag(TAG_SCENE_TUTORIAL);
	node->runAction(FadeOut::create(1.0f));
}

int GameScene::getLevel() const
{	
	return (int)(long)m_level->getUserData();
}

int GameScene::levelUp()
{
	char szlevel[16];
	long level = getLevel() + 1;
	sprintf(szlevel, "%d", level);
	m_level->setUserData((void*)level);
	m_level->setString(szlevel);

	return level;
}

bool GameScene::onContactBegin(cocos2d::PhysicsContact& contact)
{
	// ȷ��AΪС��
	auto bird = contact.getShapeA()->getBody()->getNode();
	auto node = contact.getShapeB()->getBody()->getNode();
	int tag = bird->getTag();
	
	if (TAG_SCENE_BIRD != tag)  swap(bird, node);
	tag = node->getTag();
	CC_ASSERT(bird == m_birdListener->getBird());

	if (TAG_SCENE_PIPETOP == tag || TAG_SCENE_PIPEBOT == tag || TAG_SCENE_LAND == tag)
	{
		auto mgr = GManager::getInstance();
		mgr->playSound(SNDID_DIE, false);

		pause();

		float rot = TAG_SCENE_LAND == tag ? 30 : 90;
		auto spBird = (BirdSprite*)bird;
		spBird->die(rot, getDiePosition());

		int score = getLevel();
		int best = mgr->setBestScore(score);
		addChild(OverDialog::create(score, best));
	}

	return true;
}

void GameScene::onContactSeparate(cocos2d::PhysicsContact& contact)
{
	auto bird = m_birdListener->getBird();
	if (!bird->getDieState())
	{
		int tagA = contact.getShapeA()->getBody()->getNode()->getTag();
		int tagB = contact.getShapeB()->getBody()->getNode()->getTag();
		if ((TAG_SCENE_BIRD == tagA && TAG_SCENE_PIPENODE == tagB) || (TAG_SCENE_BIRD == tagB && TAG_SCENE_PIPENODE == tagA))
		{
			int score = levelUp();
			if (score == LEVEL_MAX)
			{
				pause();

				auto mgr = GManager::getInstance();
				int best = mgr->setBestScore(score);
				mgr->playSound(SNDID_POINT);
				addChild(OverDialog::create(score, best));
			}
		}
	}
}

void GameScene::pause()
{
	stopScrollLand();
	m_patch->stopMoving();
	removeFromPhysicsWorld();
}