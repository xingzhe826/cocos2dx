#ifndef __GAME_SCENE_H__
#define __GAME_SCENE_H__

#include "BaseLayer.h"

class BirdListener;
class PatchPipe;

class GameScene : public BaseLayer
{
public:
	static GameScene* create(cocos2d::PhysicsWorld* world);
	static cocos2d::Scene* createScene();

public:
	GameScene(cocos2d::PhysicsWorld* world);
	virtual ~GameScene();

private:
	virtual bool init();
	virtual void onButton(cocos2d::Ref* pSender, cocos2d::extension::Control::EventType type);

private:
	cocos2d::Point getDiePosition() const;
	void addBackground();
	void addLogo();
	void addBird();
	void addLand();
	void addTutorial();
	void addPatchPipe();
	void addLevel();
	void addContactListener();
	void startPlay();
	int  getLevel() const;
	int  levelUp();

private:
	bool onContactBegin(cocos2d::PhysicsContact& contact);
	void onContactSeparate(cocos2d::PhysicsContact& contact);
	void pause();

private:
	BirdListener*			m_birdListener;
	PatchPipe*				m_patch;
	cocos2d::Node*			m_land;
	cocos2d::Label*			m_level;
	cocos2d::PhysicsWorld*	m_world;
};


#endif // !__GAME_SCENE_H__