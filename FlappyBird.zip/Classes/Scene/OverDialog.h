#ifndef __OVER_DIALOG_H__
#define __OVER_DIALOG_H__

#include "Objects/DialogBase.h"

class OverDialog : public DialogBase
{
public:
	static cocos2d::extension::ControlButton* createPlayButton();
	static OverDialog* create(int score, int best);

public:
	/*virtual*/ bool init(int score, int best);
	
private:
	/*virtual*/ void relayout();
	/*virtual*/ void onButton(cocos2d::Ref* pSender, cocos2d::extension::Control::EventType evType);

private:
	cocos2d::Node* createContent(int score, int best) const;
	void getDHS(int score, float& dh, float& ds) const;
};

#endif // !__OVER_DIALOG_H__
