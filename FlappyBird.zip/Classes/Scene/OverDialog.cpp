#include "OverDialog.h"
#include "Global/GManager.h"
#include "Global/GUtils.h"
#include "Objects/ColorSprite.h"
#include "cocos-ext.h"
#include "BaseLayer.h"
#include "BirdSprite.h"

using namespace cocos2d;
using namespace cocos2d::extension;

cocos2d::extension::ControlButton* OverDialog::createPlayButton()
{
	auto label = Label::createWithBMFont(PLIST_IMAGES_FNT, "0");
	label->setScale(2.0f);

	auto btn = createButton("btn0.png", label, 2.7f, 1.6f);
	btn->setScaleRatio(1.05f);
	btn->setLabelAnchorPoint(Vec2(0.5f, 0.64f));
	btn->setTag(TAG_SCENE_PLAY);
	btn->setTitleColorForState(Color3B::GREEN, Control::State::NORMAL);
	btn->setTitleColorForState(Color3B::RED, Control::State::HIGH_LIGHTED);

	return btn;
}

OverDialog* OverDialog::create(int score, int best)
{
	auto dlg = new(std::nothrow) OverDialog();
	if (NULL != dlg)
	{
		if (dlg->init(score, best))
			dlg->autorelease();
		else
			CC_SAFE_DELETE(dlg);
	}

	return dlg;
}

bool OverDialog::init(int score, int best)
{
	if (!DialogBase::init())  return false;

	auto sp = Sprite::createWithSpriteFrameName("panel.png");
	setBackground(sp);

	auto title = Label::createWithTTF("Game Over", TTF_FLAPPYBIRD, 32);
	title->setTextColor(Color4B::ORANGE);
	title->enableOutline(Color4B::WHITE, 2);
	setTitle(title);

	auto content = createContent(score, best);
	setContent(content);

	auto btn = OverDialog::createPlayButton();
	setButtonOk(btn);

	return true;
}

void OverDialog::relayout()
{
	DialogBase::relayout();
	setOffsetY(getTitle(), 40);
	setOffsetY(getButtonOk(), -81);
	setOffsetY(this, 32);
}

void OverDialog::onButton(Ref* pSender, Control::EventType evType)
{
	if (Control::EventType::TOUCH_UP_INSIDE == evType)
	{
		BirdSprite::resetColor();
		BaseLayer::resetDrak();
		GManager::getInstance()->gotoScene(SID_GAMESCENE);
	}
}

cocos2d::Node* OverDialog::createContent(int score, int best) const
{
	auto node = Node::create();
	if (score >= LEVEL_MEDAL)
	{
		auto sp = ColorSprite::createWithSpriteFrameName("medal.png");
		float dh = 0, ds = 0;
		getDHS(score, dh, ds);
		sp->setDeltaH(dh);
		sp->setDeltaS(ds);
		sp->setPosition(-64, -8);
		node->addChild(sp);
	}

	auto label = Label::createWithTTF(Integer2String(score), TTF_FLAPPYBIRD, 21);
	label->setPosition(72, 16);
	label->enableOutline(Color4B::BLACK, 1);
	node->addChild(label);

	label = Label::createWithTTF(Integer2String(best), TTF_FLAPPYBIRD, 21);
	label->setPosition(72, -27);
	label->enableOutline(Color4B::BLACK, 1);
	node->addChild(label);

	return node;
}

void OverDialog::getDHS(int score, float& dh, float& ds) const
{
	score -= LEVEL_MEDAL;
	switch (score)
	{
	case 0:  dh = 0; ds = -0.72f; break;
	case 1:  dh = 330; ds = -0.72f; break;
	case 2:  dh = 0; ds = 0; break;
	case 3:  dh = 330; ds = 0; break;
	default:  break;
	}
}