#ifndef __BASE_LAYER_H__
#define __BASE_LAYER_H__

#include "Global/GTypes.h"
#include "cocos2d.h"
#include "cocos-ext.h"

class BaseLayer : public cocos2d::Layer
{
public:
	static void resetDrak();

protected:
	BaseLayer();
	virtual ~BaseLayer();

public:
	virtual void scrollLand(float dt);
	virtual void onButton(cocos2d::Ref* pSender, cocos2d::extension::Control::EventType type);

protected:
	void addBackground();
	void addLand();
	void addLogo();
	void addBird();
	void stopScrollLand();
	
protected:
	static int8	m_drakFlag;
};

#endif // !__BASE_LAYER_H__