#ifndef __MAIN_SCENE_H__
#define __MAIN_SCENE_H__

#include "BaseLayer.h"

class MainScene : public BaseLayer
{
public:
	CREATE_FUNC(MainScene)

public:
	static cocos2d::Scene* createScene();

private:
	virtual bool init();

private:
	void addPlayButton();
};


#endif // !__MAIN_SCENE_H__