#ifndef __LOAD_SCENE_H__
#define __LOAD_SCENE_H__

#include "cocos2d.h"

class LoadScene : public cocos2d::Layer
{
public:
	CREATE_FUNC(LoadScene);

public:
    static cocos2d::Scene* createScene();

private:
    virtual bool init();

private:
	void loadCallbackAysn(cocos2d::Texture2D* texture);

private:
	bool			m_bFinished;
};

#endif // __LOAD_SCENE_H__
