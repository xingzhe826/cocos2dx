#include "BaseLayer.h"
#include "BirdSprite.h"
#include "Global/GManager.h"

using namespace cocos2d;
using namespace cocos2d::extension;

int8 BaseLayer::m_drakFlag = -1;

void BaseLayer::resetDrak()
{
	m_drakFlag = random(0, 2);
}

BaseLayer::BaseLayer()
{
	if (m_drakFlag < 0)  resetDrak();
}

BaseLayer::~BaseLayer()
{
}

void BaseLayer::scrollLand(float dt)
{
	auto land = getChildByTag(TAG_SCENE_LAND);
	float x = land->getPositionX();
	land->setPositionX(x - X_OFFSET_LAND / 2);

	auto size = Director::getInstance()->getVisibleSize();
	x = land->getBoundingBox().getMaxX();
	if (x <= size.width)  land->setPositionX(0);
}

void BaseLayer::onButton(cocos2d::Ref* pSender, cocos2d::extension::Control::EventType type)
{
	ControlButton* btn = dynamic_cast<ControlButton*>(pSender);
	if (NULL != btn)
	{
		btn->setEnabled(false);
		GManager::getInstance()->gotoScene(SID_GAMESCENE);
	}	
}

void BaseLayer::addBackground()
{
	// ���µ������ӽڵ�
	Size size = Director::getInstance()->getVisibleSize();

	// ����bg.png
	float y = 21;
	auto sp = Sprite::createWithSpriteFrameName("bg.png");
	sp->setTag(TAG_SCENE_BACKGROUND);
	sp->setAnchorPoint(Vec2::ANCHOR_MIDDLE_BOTTOM);
	sp->setPosition(size.width / 2, y - 1);
	addChild(sp);

	// ����blue sky
	auto drawSky = DrawNode::create();
	y = sp->getBoundingBox().getMaxY();
	drawSky->drawSolidRect(Point(0, y - 1), Point(size.width, size.height), Color4F(0x4e / 255.0f, 0xc0 / 255.0f, 0xca / 255.0f, 1.0f));
	addChild(drawSky);

	// ���Ӻ�ҹ
	auto lyr = LayerColor::create(Color4B(0, 0, 0, 100));
	lyr->setLocalZOrder(Z_ORDER_TOPMOST);
	lyr->setVisible(m_drakFlag != 0);
	addChild(lyr);
}

void BaseLayer::addLand()
{
	// ����land
	auto sp = Sprite::createWithSpriteFrameName("land.png");
	float y = getChildByTag(TAG_SCENE_BACKGROUND)->getBoundingBox().getMinY() + 1;
	sp->setPositionY(y);
	sp->setName("land");
	sp->setAnchorPoint(Vec2::ANCHOR_TOP_LEFT);
	sp->setTag(TAG_SCENE_LAND);
	sp->setScaleY(3.0f);
	addChild(sp);
	schedule(schedule_selector(BaseLayer::scrollLand), 0.08f);
}

void BaseLayer::addLogo()
{
	auto size = Director::getInstance()->getVisibleSize();
	auto lbl = Label::createWithTTF("Flappy Bird", TTF_FLAPPYBIRD, 49);
	lbl->setTag(TAG_SCENE_LOGO);
	lbl->setAdditionalKerning(3);
	lbl->enableShadow(Color4B::BLACK, Size(3, -4));
	lbl->setPosition(size.width / 2, size.height - 81);
	addChild(lbl);
}

void BaseLayer::addBird()
{
	auto size = Director::getInstance()->getVisibleSize();
	auto bird = BirdSprite::create();
	bird->setTag(TAG_SCENE_BIRD);
	bird->setPosition(size.width / 2, size.height / 2);
	addChild(bird);
}

void BaseLayer::stopScrollLand()
{
	unschedule(schedule_selector(BaseLayer::scrollLand));
}