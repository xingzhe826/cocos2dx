#ifndef __PATCH_PIPE_H__
#define __PATCH_PIPE_H__

//////////////////////////////////////////////////////////////////////////
// ע�����ƶ������в��ܶ��ӽڵ�������ӻ���ɾ��

#include "cocos2d.h"

using namespace cocos2d;

typedef std::function<void(cocos2d::Ref* pSender)> PipeCallback;

class PatchPipe : public cocos2d::Node
{
public:
	static PatchPipe* create(const Size& size, float xSpace);

protected:
	virtual bool init(const Size& size, float xSpace);
	virtual void onEnter();
	
public:
	void reset();
	void setPipeCallback(const PipeCallback& callback);
	void setInitPosition(const cocos2d::Point& pt);
	void setShakeY(float y);
	void startMoving(float dt, float xStep);
	void stopMoving();
	void moving(float dt, float xStep);
	
private:
	PipeCallback	m_callback;
	cocos2d::Point	m_ptInit;

	float			m_yShake;
	float			m_xSpace;
	int				m_iL;		// �ұ�����
	int				m_nChildren;

};

#endif // !__PATCH_PIPE_H__