#include "GUtils.h"
#include "cocos2d.h"

using namespace cocos2d;

long getTickCount()
{
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

int8 compare(float a, float b)
{
	a -= b;
	if (a < -FLT_EPSILON)  return -1;
	if (a < FLT_EPSILON)  return 0;
	return 1;
}

std::string Integer2String(int val)
{
	char buffer[16];
	sprintf(buffer, "%d", val);
	return buffer;
}

void setOffsetX(cocos2d::Node* node, float xOffset)
{
	CC_ASSERT(NULL != node);
	node->setPositionX(node->getPositionX() + xOffset);
}

void setOffsetY(cocos2d::Node* node, float yOffset)
{
	CC_ASSERT(NULL != node);
	node->setPositionY(node->getPositionY() + yOffset);
}

void setOffset(cocos2d::Node* node, const Vec2& ptOffset)
{
	CC_ASSERT(NULL != node);
	node->setPosition(node->getPosition() + ptOffset);
}
