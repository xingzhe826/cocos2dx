#ifndef __GLOBAL_TYPES_H__
#define __GLOBAL_TYPES_H__

#include "GConfig.h"

typedef char			int8;
typedef unsigned char	uint8;
typedef short			int16;
typedef unsigned short	uint16;


enum SoundId : uint8
{
	SNDID_DIE,
	SNDID_HIT,
	SNDID_POINT,
	SNDID_SWOOSH,
	SNDID_WING
};

enum SceneId : uint8
{
	SID_LOADSCENE,
	SID_MAINSCENE,
	SID_GAMESCENE,
};

namespace cocos2d
{
	class Vec2;
	class Node;
	class ActionInterval;
	class PhysicsBody;
	namespace extension
	{
		class ControlButton;
	}
}

#endif // !__GLOBAL_TYPES_H__