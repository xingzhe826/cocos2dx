#ifndef __GLOBAL_MANAGER_H__
#define __GLOBAL_MANAGER_H__

#include "GTypes.h"
#include "GUtils.h"

class GManager
{
public:
	static GManager* getInstance();

private:
	GManager();
	~GManager();

public:
	void init();
	void save();

public:
	int  setBestScore(int score) const;
	void playSound(SoundId id, bool bRepeat = false);
	void stopAllEffect();
	void gotoScene(SceneId id);
};

#endif