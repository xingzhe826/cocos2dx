#ifndef __GLOBAL_CONFIG_H__
#define __GLOBAL_CONFIG_H__

//////////////////////////////////////////////////////////////////////////
// ��ͨ��

#define LEVEL_MAX					10
#define LEVEL_MEDAL					(LEVEL_MAX-3)

#define X_OFFSET_LAND				21
#define X_OFFSET_PIPE				6
#define FX_DIST_PIPE				0.75f
#define FY_DIST_PIPE				0.26f
#define FY_SHAKE_PIPE				0.27f

// #define Z_ORDER_PIPE				997
// #define Z_ORDER_LAND				998
#define Z_ORDER_TOPMOST				999

#define GRAVITY_VALUE				240

// ��ײ����Mask
#define MASK_CATEGORY_BIRD			0x01		// Default: 0xffffffff
#define MASK_CATEGORY_PIPE			-1			// Default: 0xffffffff
#define MASK_CATEGORY_PIPENODE		-1			// Default: 0xffffffff
#define MASK_CATEGORY_LAND			-1			// Default: 0xffffffff
#define MASK_CATEGORY_CEILING		-1			// Default: 0xffffffff

#define MASK_COLLISION_BIRD			-1			// Default: 0xffffffff
#define MASK_COLLISION_PIPE			-1			// Default: 0xffffffff
#define MASK_COLLISION_PIPENODE		0x10		// Default: 0xffffffff
#define MASK_COLLISION_LAND			-1			// Default: 0xffffffff
#define MASK_COLLISION_CEILING		-1			// Default: 0xffffffff

#define MASK_CONTACTTEST_BIRD		0x01		// Default: 0x00000000
#define MASK_CONTACTTEST_PIPE		0x01		// Default: 0x00000000
#define MASK_CONTACTTEST_PIPENODE	0x01		// Default: 0x00000000
#define MASK_CONTACTTEST_LAND		0x01		// Default: 0x00000000
#define MASK_CONTACTTEST_CEILING	0			// Default: 0x00000000

#define TAG_SCENE_BACKGROUND		1000
#define TAG_SCENE_LOGO				1001
#define TAG_SCENE_PATCHPIPE			1002
#define TAG_SCENE_PIPENODE			1003
#define TAG_SCENE_PIPETOP			1004
#define TAG_SCENE_PIPEBOT			1005
#define TAG_SCENE_LEVEL				1006
#define TAG_SCENE_BIRD				1007
#define TAG_SCENE_LAND				1008
#define TAG_SCENE_TUTORIAL			1009
#define TAG_SCENE_PLAY				1010

#define TAG_ACTION_BIRD_UP			1000
#define TAG_ACTION_BIRD_UD			1001

#define TAG_ACTION_BIRD_WING		1000
#define TAG_ACTION_BIRD_IDLE		1002

//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// ��Դ�ļ�
#if defined(_WIN32) || defined(WIN32)
#	define MSC_DIE			"msc/die.mp3"
#	define MSC_HIT			"msc/hit.mp3"
#	define MSC_POINT		"msc/point.mp3"
#	define MSC_SWOOSH		"msc/swoosh.mp3"
#	define MSC_WING			"msc/wing.mp3"
#else
#	define MSC_DIE			"msc/die.ogg"
#	define MSC_HIT			"msc/hit.ogg"
#	define MSC_POINT		"msc/point.ogg"
#	define MSC_SWOOSH		"msc/swoosh.ogg"
#	define MSC_WING			"msc/wing.ogg"
#endif //  defined(_WIN32) || defined(WIN32)

#define PLIST_IMAGES_PLIST	"plist/images.plist"
#define PLIST_IMAGES_PNG	"plist/images.png"
#define PLIST_IMAGES_FNT	"plist/images.fnt"
#define TTF_FLAPPYBIRD		"fonts/FlappyBird.ttf"

//////////////////////////////////////////////////////////////////////////

#endif // !__GLOBAL_CONFIG_H__