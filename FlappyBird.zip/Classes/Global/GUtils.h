#ifndef __GLOBAL_UTILS_H__
#define __GLOBAL_UTILS_H__

#include "GTypes.h"
#include <string>

#ifndef arraycount
#	define arraycount(a)	(sizeof(a) / sizeof(a[0]))
#endif

template<class T>
void swap(T& a, T& b){  T tmp = a;  a = b;  b = tmp;}

long getTickCount();
int8 compare(float a, float b);

std::string Integer2String(int val);
void setOffsetX(cocos2d::Node* node, float xOffset);
void setOffsetY(cocos2d::Node* node, float yOffset);
void setOffset(cocos2d::Node* node, const cocos2d::Vec2& ptOffset);

#endif // !__GLOBAL_UTILS_H__