#include "GManager.h"
#include "cocos2d.h"
#include "SimpleAudioEngine.h"
#include "Scene/LoadScene.h"
#include "Scene/MainScene.h"
#include "Scene/GameScene.h"


using namespace cocos2d;
using namespace CocosDenshion;

GManager* GManager::getInstance()
{
	static GManager mgr;
	return &mgr;
}

GManager::GManager()
{
	srand(getTickCount());
}

GManager::~GManager()
{
}

void GManager::init()
{
	// ��Դ����
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile(PLIST_IMAGES_PLIST);
	SimpleAudioEngine::getInstance()->preloadEffect(MSC_DIE);
	SimpleAudioEngine::getInstance()->preloadEffect(MSC_HIT);
	SimpleAudioEngine::getInstance()->preloadEffect(MSC_POINT);
	SimpleAudioEngine::getInstance()->preloadEffect(MSC_SWOOSH);
	SimpleAudioEngine::getInstance()->preloadEffect(MSC_WING);
}

void GManager::save()
{
}

int GManager::setBestScore(int score) const
{
	int best = UserDefault::getInstance()->getIntegerForKey("best");
	if (best < score)
	{
		best = score;
		UserDefault::getInstance()->setIntegerForKey("best", best);
	}

	return best;
}

void GManager::playSound(SoundId id, bool bRepeat)
{
	switch (id)
	{
	case SNDID_DIE:
		SimpleAudioEngine::getInstance()->playEffect(MSC_DIE, bRepeat);
		break;
	case SNDID_HIT:
		SimpleAudioEngine::getInstance()->playEffect(MSC_HIT, bRepeat);
		break;
	case SNDID_POINT:
		SimpleAudioEngine::getInstance()->playEffect(MSC_POINT, bRepeat);
		break;
	case SNDID_SWOOSH:
		SimpleAudioEngine::getInstance()->playEffect(MSC_SWOOSH, bRepeat);
		break;
	case SNDID_WING:
		SimpleAudioEngine::getInstance()->playEffect(MSC_WING, bRepeat);
		break;
	default:
		break;
	}
}

void GManager::stopAllEffect()
{
	SimpleAudioEngine::getInstance()->stopAllEffects();
}

void GManager::gotoScene(SceneId id)
{
	Scene* scene = NULL;
	switch (id)
	{
	case SID_LOADSCENE:
		scene = LoadScene::createScene();
		break;
	case SID_MAINSCENE:
		scene = MainScene::createScene();
		break;
	default:	// SID_GAMESCENE
		scene = GameScene::createScene();
//		scene = TransitionCrossFade::create(0.3f, scene);
		break;
	}
	playSound(SNDID_SWOOSH);
	Director::getInstance()->replaceScene(scene);
}