#include "ccShader_Color_HSL.frag"
#include "ColorSprite.h"
#include "cocos2d.h"

using namespace cocos2d;

ColorSprite::ColorSprite() : m_dH(0), m_dS(0), m_dL(0)
{
}

ColorSprite::~ColorSprite()
{
}

ColorSprite* ColorSprite::create()
{
	ColorSprite* sp = new (std::nothrow) ColorSprite();
	if (NULL != sp)
	{
		if (sp->init())
			sp->autorelease();
		else
			CC_SAFE_DELETE(sp);
	}
	
	return sp;
}

ColorSprite* ColorSprite::create(const std::string& filename)
{
	ColorSprite* sp = new (std::nothrow) ColorSprite();
	if (NULL != sp)
	{
		if (sp->initWithFile(filename))
			sp->autorelease();
		else
			CC_SAFE_DELETE(sp);
	}
	
	return sp;
}

ColorSprite* ColorSprite::create(const std::string& filename, const cocos2d::Rect& rect)
{
	ColorSprite* sp = new (std::nothrow) ColorSprite();
	if (NULL != sp)
	{
		if (sp->initWithFile(filename, rect))
			sp->autorelease();
		else
			CC_SAFE_DELETE(sp);
	}
	
	return sp;
}

ColorSprite* ColorSprite::createWithTexture(cocos2d::Texture2D *texture)
{
	ColorSprite* sp = new (std::nothrow) ColorSprite();
	if (NULL != sp)
	{
		Rect rect = Rect::ZERO;
		rect.size = texture->getContentSize();
		if (sp->initWithTexture(texture, rect, false))
			sp->autorelease();
		else
			CC_SAFE_DELETE(sp);
	}

	return sp;
}

ColorSprite* ColorSprite::createWithTexture(cocos2d::Texture2D *texture, const cocos2d::Rect& rect, bool rotated /*=false*/)
{
	ColorSprite* sp = new (std::nothrow) ColorSprite();
	if (NULL != sp)
	{
		if (sp->initWithTexture(texture, rect, rotated))
			sp->autorelease();
		else
			CC_SAFE_DELETE(sp);
	}
	
	return sp;
}

ColorSprite* ColorSprite::createWithSpriteFrame(SpriteFrame* spriteFrame)
{
	ColorSprite* sp = new (std::nothrow) ColorSprite();
	if (NULL != sp)
	{
		if (sp->initWithSpriteFrame(spriteFrame))
			sp->autorelease();
		else
			CC_SAFE_DELETE(sp);
	}

	return sp;
}

ColorSprite* ColorSprite::createWithSpriteFrameName(const std::string& spriteFrameName)
{
	SpriteFrame *frame = SpriteFrameCache::getInstance()->getSpriteFrameByName(spriteFrameName);
	CC_ASSERT(NULL != frame);
	return createWithSpriteFrame(frame);
}

bool ColorSprite::initWithTexture(cocos2d::Texture2D *texture, const cocos2d::Rect& rect, bool rotated)
{
	if (Sprite::initWithTexture(texture, rect, rotated))
	{
		auto glprogram = GLProgram::createWithByteArrays(ccPositionTextureColor_noMVP_vert, ccPositionTexture_ColorHSL_frag);
		auto glprogramstate = GLProgramState::getOrCreateWithGLProgram(glprogram);
		setGLProgramState(glprogramstate);

		CHECK_GL_ERROR_DEBUG();
	}
	return true;
}

void ColorSprite::grayScale(cocos2d::Node* sp)
{
	auto glprogram = GLProgram::createWithByteArrays(ccPositionTextureColor_noMVP_vert, ccPositionTexture_GrayScale_frag);
	sp->setGLProgram(glprogram);
}

void ColorSprite::draw(cocos2d::Renderer *renderer, const cocos2d::Mat4 &transform, uint32_t flags)
{
	auto glProgramState = getGLProgramState();
	glProgramState->setUniformFloat("u_dH", m_dH);
	glProgramState->setUniformFloat("u_dS", m_dS);
	glProgramState->setUniformFloat("u_dL", m_dL);

	Sprite::draw(renderer, transform, flags);
}
