#ifndef __DIALOG_BASE_H__
#define __DIALOG_BASE_H__

#include "cocos2d.h"
#include "extensions/GUI/CCControlExtension/CCControlButton.h"

enum : unsigned char
{
	TAG_DLG_BACKGROUND,
	TAG_DLG_HEAD,
	TAG_DLG_TITLE,
	TAG_DLG_CONTENT,
	TAG_DLG_FOOT,
	TAG_DLG_BUTTON_OK,
	TAG_DLG_BUTTON_CANCEL,
	TAG_DLG_BUTTON_CLOSE
};

typedef std::function<bool(cocos2d::Node*,int)>	DialogCallback;

class DialogBase : public cocos2d::Node
{
public:
	static cocos2d::extension::ControlButton* createButton(const char* frm9, cocos2d::Node* label = NULL, float sx = 1.0f, float sy = 1.0f);

public:
	CREATE_FUNC(DialogBase)
	CC_SYNTHESIZE(bool, m_bAutoRelayout, AutoRelayout)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_background, Background)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_head, Head)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_title, Title)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_content, Content)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_foot, Foot)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_btnOk, ButtonOk)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_btnCcl, ButtonCancel)
	CC_SYNTHESIZE_RETAIN(cocos2d::Node*, m_btnCls, ButtonClose)
	CC_SYNTHESIZE_RETAIN(cocos2d::Action*, m_actionEffect, ActionEffect)

public:
	virtual bool init();
	virtual void onEnter();
	virtual void onExit();
	virtual void relayout();
	virtual void onButton(cocos2d::Ref* pSender, cocos2d::extension::Control::EventType evType);
	virtual bool onTouchBegan(cocos2d::Touch *touch, cocos2d::Event* unused_event);
	virtual void onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* unused_event);
	virtual void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* unused_event);
	virtual void onTouchCancelled(cocos2d::Touch* touch, cocos2d::Event* unused_event);
	
public:
	void addNode(cocos2d::Node* node, int tag);
	void setSwallowTouches(bool needSwallow);

private:
	cocos2d::ActionInterval* DialogBase::createZoom() const;
	cocos2d::Size getDialogSize() const;

	void setNodePosition(cocos2d::Node* node, const cocos2d::Size& size,
		const cocos2d::Vec2& anchor, const cocos2d::Point& ptOffset, int xMulti = 0, int yMulti = 0) const;
	void setBottomButtons(const cocos2d::Size& size, const cocos2d::Point& ptOffset);
	void addChildren();
	void addListener();

protected:
	cocos2d::EventListenerTouchOneByOne* m_listenerTouchOneByOne;
	DialogCallback						 m_callback;
};

#endif // !__DIALOG_BASE_H__