#include "DialogBase.h"

using namespace cocos2d;
using namespace cocos2d::extension;

ControlButton* DialogBase::createButton(const char* frm9, cocos2d::Node* label /* = NULL */, float sx /* = 1.0f */, float sy /* = 1.0f */)
{
	auto sp9 = ui::Scale9Sprite::createWithSpriteFrameName(frm9);
	auto size = sp9->getContentSize();
	size.width *= sx;
	size.height *= sy;
	sp9->setPreferredSize(size);

	auto btn = NULL != label ? ControlButton::create(label, sp9) : ControlButton::create(sp9);
	btn->setAdjustBackgroundImage(false);

	return btn;
}

bool DialogBase::init()
{
	if (!Node::init())  return false;

	setAutoRelayout(true);

	m_background = NULL;
	m_head = NULL;
	m_title = NULL;
	m_content = NULL;
	m_foot = NULL;
	m_btnOk = NULL;
	m_btnCcl = NULL;
	m_btnCls = NULL;
	m_actionEffect = createZoom();

	addListener();
	
	return true;
}

void DialogBase::onEnter()
{
	addChildren();
	relayout();

	Node::onEnter();

	auto effect = getActionEffect();
	if (NULL != effect)  runAction(effect);
}

void DialogBase::onExit()
{
	CC_SAFE_RELEASE(m_background);
	CC_SAFE_RELEASE(m_head);
	CC_SAFE_RELEASE(m_title);
	CC_SAFE_RELEASE(m_content);
	CC_SAFE_RELEASE(m_foot);
	CC_SAFE_RELEASE(m_btnOk);
	CC_SAFE_RELEASE(m_btnCcl);
	CC_SAFE_RELEASE(m_btnCls);
	
	Node::onExit();
}

void DialogBase::addListener()
{
	m_listenerTouchOneByOne = EventListenerTouchOneByOne::create();
	m_listenerTouchOneByOne->onTouchBegan = CC_CALLBACK_2(DialogBase::onTouchBegan, this);
	m_listenerTouchOneByOne->onTouchMoved = CC_CALLBACK_2(DialogBase::onTouchMoved, this);
	m_listenerTouchOneByOne->onTouchEnded = CC_CALLBACK_2(DialogBase::onTouchEnded, this);
	m_listenerTouchOneByOne->onTouchCancelled = CC_CALLBACK_2(DialogBase::onTouchCancelled, this);
	m_listenerTouchOneByOne->setSwallowTouches(true);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(m_listenerTouchOneByOne, this);
}

void DialogBase::relayout()
{
	// ȷ������λ��
	if (getAutoRelayout())
	{// �Զ��Ű�[Ĭ�����н��ê��ΪVec2::ANCHOR_MIDDLE
		auto size = getDialogSize();
		Point ptOffset(size.width * 0.01f, size.height * 0.01f * size.height / size.width);

		setNodePosition(m_background, size, Vec2::ANCHOR_MIDDLE, Vec2::ZERO);
		setNodePosition(m_head, size, Vec2::ANCHOR_MIDDLE_TOP, ptOffset, 0, 1);
		setNodePosition(m_title, size, Vec2::ANCHOR_MIDDLE_TOP, ptOffset, 0, -1);
		setNodePosition(m_content, size, Vec2::ANCHOR_MIDDLE, Vec2::ZERO);
		setNodePosition(m_btnCls, size, Vec2::ANCHOR_TOP_RIGHT, ptOffset, 1, -1);
		setNodePosition(m_foot, size, Vec2::ANCHOR_MIDDLE_BOTTOM, ptOffset, 0, -1);
		setBottomButtons(size, ptOffset);

		setContentSize(size);
		setAnchorPoint(Vec2::ANCHOR_MIDDLE);

		size = getParent()->getContentSize();
		setPosition(size.width / 2, size.height / 2);
	}
}

void DialogBase::onButton(cocos2d::Ref* pSender, cocos2d::extension::Control::EventType evType)
{
	if (NULL != m_callback)  m_callback((Node*)pSender, (int)evType);
}

bool DialogBase::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event* unused_event)
{
	CCLOG("%s", __FUNCTION__);
	return true;
}

void DialogBase::onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* unused_event)
{
	CCLOG("%s", __FUNCTION__);
}

void DialogBase::onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* unused_event)
{
	CCLOG("%s", __FUNCTION__);
}

void DialogBase::onTouchCancelled(cocos2d::Touch* touch, cocos2d::Event* unused_event)
{
}

void DialogBase::addNode(cocos2d::Node* node, int tag)
{
	if (NULL != node)
	{
		auto btn = dynamic_cast<ControlButton*>(node);
		if (btn)
		{
			btn->addTargetWithActionForControlEvents(this, cccontrol_selector(DialogBase::onButton), Control::EventType::TOUCH_DOWN);
			btn->addTargetWithActionForControlEvents(this, cccontrol_selector(DialogBase::onButton), Control::EventType::TOUCH_UP_INSIDE);
		}
		
		node->setTag(tag);	
		addChild(node);
	}
}

void DialogBase::setSwallowTouches(bool needSwallow)
{
	m_listenerTouchOneByOne->setSwallowTouches(needSwallow);
}

cocos2d::ActionInterval* DialogBase::createZoom() const
{
	return Sequence::create(ScaleTo::create(0.0f, 0.0f),
		ScaleTo::create(0.2f, 1.05f), ScaleTo::create(0.1f, 0.95f), ScaleTo::create(0.1f, 1.0f), NULL);;
}

cocos2d::Size DialogBase::getDialogSize() const
{
	auto size = getContentSize();
	if (size.equals(Size::ZERO))
	{
		if (NULL == m_background)
		{
			size = Director::getInstance()->getVisibleSize();
			size.width *= 0.72f;
			size.height *= 0.64f;
		}
		else
			size = m_background->getBoundingBox().size;

	}

	return size;
}

void DialogBase::setNodePosition(cocos2d::Node* node, const cocos2d::Size& size,
	const cocos2d::Vec2& anchor, const cocos2d::Point& ptOffset, int xMulti /* = 0 */, int yMulti /* = 0 */) const
{
	if (NULL != node)
	{
		auto& sz = node->getBoundingBox().size;
		float x = size.width * anchor.x + xMulti * (sz.width / 2 + ptOffset.x);
		float y = size.height * anchor.y + yMulti * (sz.height / 2 + ptOffset.y);
		node->setPosition(x, y);
	}
}

void DialogBase::setBottomButtons(const cocos2d::Size& size, const cocos2d::Point& ptOffset)
{
	int flag = 0;
	Size size0;
	Size size1;
	if (m_btnOk)
	{
		size0 = m_btnOk->getBoundingBox().size;
		flag |= 0x01;
	}
	if (m_btnCcl)
	{
		size1 = m_btnCcl->getBoundingBox().size;
		flag |= 0x02;
	}
	switch (flag)
	{
	case 0x01:	// NULL��= m_btnOK
		m_btnOk->setPosition(size.width / 2, size0.height / 2 + ptOffset.y);
		break;
	case 0x02:	// NULL��= m_btnCcl
		m_btnCcl->setPosition(size.width / 2, size1.height / 2 + ptOffset.y);
		break;
	case 0x03:	// NULL��= m_btnCcl && NULL��= m_btnOK
		if (size0.width - size1.width < -1e-6)  size0.width = size1.width;
		if (size0.height - size1.height < -1e-6)  size0.height = size1.height;
		m_btnOk->setPosition(size.width / 2 - size0.width / 2 - ptOffset.x * 2, size0.height / 2 + ptOffset.y);
		m_btnCcl->setPosition(size.width / 2 + size0.width / 2 + ptOffset.x * 2, size0.height / 2 + ptOffset.y);
		break;
	default:	// 0x00--- NULL == m_btnOK && NULL == m_btnCcl
		break;
	}
}

void DialogBase::addChildren()
{
	addNode(m_background, TAG_DLG_BACKGROUND);
	addNode(m_head, TAG_DLG_HEAD);
	addNode(m_title, TAG_DLG_TITLE);
	addNode(m_content, TAG_DLG_CONTENT);
	addNode(m_foot, TAG_DLG_FOOT);
	addNode(m_btnOk, TAG_DLG_BUTTON_OK);
	addNode(m_btnCcl, TAG_DLG_BUTTON_CANCEL);
	addNode(m_btnCls, TAG_DLG_BUTTON_CLOSE);
}
