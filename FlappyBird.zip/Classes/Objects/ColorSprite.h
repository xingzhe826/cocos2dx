#ifndef __COLOR_SPRITE_H__
#define __COLOR_SPRITE_H__

/**
 * author:	 xingzhe826
 * date:	 2015/09/15
 * function: Change the HSL of Sprite
**/

#include "2d/CCSprite.h"

class ColorSprite : public cocos2d::Sprite
{
protected:
	ColorSprite();
	virtual ~ColorSprite();

public:
    static ColorSprite* create();
    static ColorSprite* create(const std::string& filename);
    static ColorSprite* create(const std::string& filename, const cocos2d::Rect& rect);
    static ColorSprite* createWithTexture(cocos2d::Texture2D* texture);
    static ColorSprite* createWithTexture(cocos2d::Texture2D* texture, const cocos2d::Rect& rect, bool rotated = false);
    static ColorSprite* createWithSpriteFrame(cocos2d::SpriteFrame* spriteFrame);
    static ColorSprite* createWithSpriteFrameName(const std::string& spriteFrameName);

public:
	static void grayScale(cocos2d::Node* sp);
	
protected:
	virtual bool initWithTexture(cocos2d::Texture2D* texture, const cocos2d::Rect& rect, bool rotated);
	virtual void draw(cocos2d::Renderer *renderer, const cocos2d::Mat4 &transform, uint32_t flags);
	
public:
	CC_SYNTHESIZE(float, m_dH, DeltaH)	 // ɫ��: Hue------------------	[0,360)
	CC_SYNTHESIZE(float, m_dS, DeltaS)	 // ���Ͷ�: Saturation---------	[-1,1]
	CC_SYNTHESIZE(float, m_dL, DeltaL)	 // ����: Lightness------------	[-1,1]
};

#endif // !__COLOR_SPRITE_H__